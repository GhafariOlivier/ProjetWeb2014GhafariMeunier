<?php

namespace Savanna\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SavannaPlatformBundle extends Bundle
{
}
